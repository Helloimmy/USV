clc
clear all
%% ��ʼ��״̬����
kalman.epsilo = 0.015; %����
kalman.iteration = 100; %�����50��
kalman.num_Follower = 4;    %Follower������������Ϊ2���޸�ʱ�ǵ��޸�H��minus
kalman.K = 1;  %��ǰ��������
kalman.A = eye(2);
kalman.B = zeros(2);
kalman.x.real = [3; 3]; %x����ʵֵ

kalman.y = zeros(2, 1);    %fused information vector
kalman.S = zeros(2, 2);    %fused information matrices
kalman.x.minus_sum = zeros(2, 1);
kalman.w = wgn(2,kalman.iteration, 0)/50;    %��ʵֵ�ĸ�˹��������
for i = 1: kalman.iteration
    kalman.Q(:, :, i) =  0.02;    %��ʵֵ�ĸ�˹��������Э����
end

Follower(1).kalman.H = [1, 0; 0, 1];
Follower(2).kalman.H = [1, 0; 0, 1];
Follower(3).kalman.H = [1, 0; 0, 1];
Follower(4).kalman.H = [1, 0; 0, 1];
Follower(1).kalman.x.minus = [9; 9];
Follower(2).kalman.x.minus = [9; 9];
Follower(3).kalman.x.minus = [9; 9];
Follower(4).kalman.x.minus = [9; 9];

for i = 1:kalman.num_Follower
    Follower(i).kalman.P = [1, 0; 0, 1];    %�������Э�������
    Follower(i).kalman.x.hat = zeros(2, 1); %�������ֵ
    Follower(i).kalman.z = zeros(2,1);    %���ֵ
    Follower(i).kalman.R = 4*ones(2,2);  %R��ʾz��Э�������ֵ������Э�����R��ֵԽС�������ٶ�Խ��
    Follower(i).kalman.u = zeros(2, 1); %information vector
    Follower(i).kalman.U = zeros(2, 2); %information matrix
    Follower(i).kalman.M = zeros(2, 2);
    Follower(i).kalman.gamma = 0;
    Follower(i).kalman.v = wgn(2, kalman.iteration, 0)*2; %��ֵ֪�ĸ�˹��������
end

%% ͼ����ʾ
% figure
% hold on
plotfig.xreal = zeros(2, kalman.iteration);
plotfig.z = zeros(2, kalman.iteration);
plotfig.xhat = zeros(2, kalman.iteration);
plotfig.ex = zeros(2, kalman.iteration);
plotfig.P = zeros(1, kalman.iteration);
plotfig.time = 0;

%% ѭ��
for j = 1:kalman.iteration
    plotfig.time = plotfig.time + 1;
    kalman.K = j;
    
    for i = 1:kalman.num_Follower
%% Obtain measurement zi with covariance Ri.
% for i = 1:4
%     z(:, :, i) = H(:, :, i)*x.real(:, :, K)+v(:, K, i);  %wgnΪ���ɸ�˹��������matlab����
%     R(:, :, i) =10*ones(2,2);
% end
        Follower(i).kalman.z = Follower(i).kalman.H*kalman.x.real + Follower(i).kalman.v(:, kalman.K);

%% Compute information vector and matrix of node i.
% for i = 1:4
%     u(:, :, i) = H(:, :, i)'*R(1, 1, i)^-1*z(:, :, i);
%     U(:, :, i) = H(:, :, i)'*R(1, 1, i)^-1*H(:, :, i);
% end
        Follower(i).kalman.u = Follower(i).kalman.H*(Follower(i).kalman.R(1,1))^-1*Follower(i).kalman.z;
        Follower(i).kalman.U = Follower(i).kalman.H*(Follower(i).kalman.R(1,1))^-1*Follower(i).kalman.H;
    end

%% Broadcast message mi to neighbors.

%% Receive messages from all neighbors.

%% Fuse information matrices and vectors
% for i = 1:4
%     y = sum(u,3);
%     S = sum(U,3);
% end
    kalman.y = Follower(1).kalman.u;
    kalman.S = Follower(1).kalman.U;
    kalman.x.minus_sum = Follower(1).kalman.x.minus;
    for i = 2:kalman.num_Follower
        kalman.y = kalman.y+Follower(i).kalman.u;
        kalman.S = kalman.S+Follower(i).kalman.U;
        kalman.x.minus_sum = kalman.x.minus_sum+Follower(i).kalman.x.minus;
    end

    for i = 1:kalman.num_Follower
%% Compute the Kalman-Consensus state estimate
% for i = 1:4
%     M(:, :, i) = (P(:,:,i)^-1+S^-1)^-1;
%     gamma = epsilo / (norm(P(:, :, i))+1);
%     x.hat(:, :, i) = x.minus(:, :, i) + M(:, :, i)*(y - S*x.minus(:, :, i)) + gamma*P(:,:,i)*(sum(x.minus, 3)-4*x.minus(:, :, i));
% end
        Follower(i).kalman.M = (((Follower(i).kalman.P)^-1) + ((kalman.S)^-1))^-1;
        Follower(i).kalman.gamma = kalman.epsilo / (norm(Follower(i).kalman.P)+1);
        Follower(i).kalman.x.hat = Follower(i).kalman.x.minus + Follower(i).kalman.M*(kalman.y-kalman.S*Follower(i).kalman.x.minus) + Follower(i).kalman.gamma*Follower(i).kalman.P*(kalman.x.minus_sum-kalman.num_Follower*Follower(i).kalman.x.minus);

%% Update the state of the local information filter
% for i = 1:4
%     P(:,:,i) = A*M(:, :, i)*A' + B*Q(:, :, K)*B';
%     x.minus(:, :, i) = A*x.hat(:, :, i);
% end
        Follower(i).kalman.P = kalman.A*Follower(i).kalman.M*kalman.A' + kalman.B*kalman.Q(:, :, kalman.K)*kalman.B';
        Follower(i).kalman.x.minus = kalman.A*Follower(i).kalman.x.hat;
%     kalman.x.real(:, :, kalman.K) = kalman.A*kalman.x.real(:, :, kalman.K-1) + kalman.B*kalman.w(:, kalman.K);
    end
    plotfig.xreal(:, plotfig.time)=kalman.x.real;
    plotfig.z(:, plotfig.time)=Follower(1).kalman.z;
    plotfig.xhat(:, plotfig.time)=Follower(1).kalman.x.hat;
    plotfig.ex(:, plotfig.time) = abs(kalman.x.real - Follower(1).kalman.x.hat);
    plotfig.P(:, plotfig.time) = Follower(1).kalman.P(1,1);
end

%% ��ͼ
% for i = 1:kalman.num_Follower
%     plot(Follower(i).kalman.x.hat(1, 1), Follower(i).kalman.x.hat(2, 1), '-oc')
% end

%% ��ͼ����
LineWidth=3;
t = 1:kalman.iteration;
figure
hold on
% ax1 = subplot(2,1,1); % top subplot
% ax2 = subplot(2,1,2); % bottom subplot
plot(t, plotfig.z(1,:),'k+');plot(t, plotfig.xreal(1,:),'b-','LineWidth',LineWidth);plot( t, plotfig.xhat(1,:),'r-','LineWidth',LineWidth)
axis([0 100 -2 8])
legend('����ֵ','����ֵ','�������ֵ')
xlabel('��������')
ax = gca;
ax.FontSize = 13;
box on
% plot(ax1, t, plotfig.z(1,:))
% plot(ax1, t, plotfig.xhat(1,:))
% plot(ax2, t, plotfig.xreal(2,:), t, plotfig.z(2,:), t, plotfig.xhat(2,:))
% plot(ax2, t, plotfig.z(2,:))
% plot(ax2, t, plotfig.xhat(2,:))
figure
plot(t, plotfig.P,'LineWidth',LineWidth)
axis([0 100 0 1])
xlabel('��������')
ylabel('������Ʒ���')
ax = gca;
ax.FontSize = 13;
box on
figure
ax1 = subplot(2,1,1); % top subplot
ax2 = subplot(2,1,2); % bottom subplot
plot(ax1, t, plotfig.ex(1,:))
plot(ax2, t, plotfig.ex(2,:))